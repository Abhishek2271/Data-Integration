==================================
How to Guide To Do Entity Matching
==================================

The initial draft of the how to guide to do entity matching can be found `here. <http://pradap-www.cs.wisc.edu/magellan/how-to-guide/how_to_guide_magellan.pdf>`_ 
