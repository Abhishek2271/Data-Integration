========
Labeling
========
.. autofunction:: py_entitymatching.label_table
.. autofunction:: py_entitymatching.new_label_table
