====================
Supported Tokenizers
====================
.. autofunction:: py_entitymatching.tok_qgram
.. autofunction:: py_entitymatching.tok_delim
.. autofunction:: py_entitymatching.tok_wspace
.. autofunction:: py_entitymatching.tok_alphabetic
.. autofunction:: py_entitymatching.tok_alphanumeric