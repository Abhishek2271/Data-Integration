========================
Debugging Blocker Output
========================
.. autofunction:: py_entitymatching.debug_blocker