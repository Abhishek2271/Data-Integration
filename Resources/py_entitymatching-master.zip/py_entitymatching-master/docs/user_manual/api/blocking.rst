========
Blocking
========
.. autoclass:: py_entitymatching.AttrEquivalenceBlocker
    :members:
.. autoclass:: py_entitymatching.OverlapBlocker
    :members:
.. autoclass:: py_entitymatching.RuleBasedBlocker
    :members:
.. autoclass:: py_entitymatching.BlackBoxBlocker
    :members:
