=========================
Combining Blocker Outputs
=========================
.. autofunction:: py_entitymatching.combine_blocker_outputs_via_union