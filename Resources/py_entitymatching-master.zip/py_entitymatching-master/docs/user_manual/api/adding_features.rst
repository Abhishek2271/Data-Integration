================================
Adding Features to Feature Table
================================
.. autofunction:: py_entitymatching.get_feature_fn
.. autofunction:: py_entitymatching.add_feature
.. autofunction:: py_entitymatching.add_blackbox_feature
