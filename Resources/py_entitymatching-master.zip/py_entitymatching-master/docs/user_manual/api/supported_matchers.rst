==================
Supported Matchers
==================

ML Matchers
===========

.. autoclass:: py_entitymatching.DTMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__

.. autoclass:: py_entitymatching.RFMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__

.. autoclass:: py_entitymatching.SVMMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__

.. autoclass:: py_entitymatching.NBMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__

.. autoclass:: py_entitymatching.LinRegMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__


.. autoclass:: py_entitymatching.LogRegMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__


.. autoclass:: py_entitymatching.XGBoostMatcher
    :inherited-members:
    :exclude-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__


Rule-Based Matcher
==================

 .. autoclass:: py_entitymatching.BooleanRuleMatcher
    :inherited-members:
    :excluded-members: __delattr__, __format__, __getattribute__, __hash__, __reduce__, __reduce_ex__, __repr__, __setattr__, __sizeof__, __str__
