==============================
Creating the Features Manually
==============================

.. autofunction:: py_entitymatching.get_features
.. autofunction:: py_entitymatching.get_attr_corres
.. autofunction:: py_entitymatching.get_attr_types
.. autofunction:: py_entitymatching.get_sim_funs_for_blocking
.. autofunction:: py_entitymatching.get_sim_funs_for_matching
.. autofunction:: py_entitymatching.get_tokenizers_for_blocking
.. autofunction:: py_entitymatching.get_tokenizers_for_matching
