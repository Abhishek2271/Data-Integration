============
Downsampling
============
.. autofunction:: py_entitymatching.down_sample