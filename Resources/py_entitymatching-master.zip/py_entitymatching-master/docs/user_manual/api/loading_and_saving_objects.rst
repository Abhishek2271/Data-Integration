============================
Loading and Saving Objects
============================
.. autofunction:: py_entitymatching.load_table
.. autofunction:: py_entitymatching.save_table
.. autofunction:: py_entitymatching.load_object
.. autofunction:: py_entitymatching.save_object
