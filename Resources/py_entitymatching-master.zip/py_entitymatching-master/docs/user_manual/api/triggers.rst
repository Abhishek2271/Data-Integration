========
Triggers
========
.. autoclass:: py_entitymatching.MatchTrigger
    :members:
