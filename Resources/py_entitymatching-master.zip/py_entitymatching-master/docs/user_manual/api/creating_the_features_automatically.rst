===================================
Creating the Features Automatically
===================================

.. autofunction:: py_entitymatching.get_features_for_blocking
.. autofunction:: py_entitymatching.get_features_for_matching

