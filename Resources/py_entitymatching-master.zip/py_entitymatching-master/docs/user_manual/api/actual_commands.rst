=============================
Commands in py_entitymatching
=============================

.. toctree::
    :maxdepth: 3

    reading_and_writing_data
    loading_and_saving_objects
    handling_metadata
    downsampling
    data_exploration
    blocking
    debugging_blocker_output
    combining_blocker_outputs
    sampling
    labeling
    handling_features
    matching
    debugging_matcher
    triggers
    evaluating_the_matching_output
