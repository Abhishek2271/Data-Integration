================
Data Exploration
================
.. autoclass:: py_entitymatching.data_explore_openrefine
.. autoclass:: py_entitymatching.data_explore_pandastable
