==================
Selecting Matcher
==================
.. autofunction:: py_entitymatching.select_matcher