==================================
Splitting Data into Train and Test
==================================
.. autofunction:: py_entitymatching.split_train_test