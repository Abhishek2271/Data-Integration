=========================
Reading and Writing Data
=========================
.. autofunction:: py_entitymatching.read_csv_metadata
.. autofunction:: py_entitymatching.to_csv_metadata
