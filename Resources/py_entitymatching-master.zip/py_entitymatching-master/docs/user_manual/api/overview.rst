================================
Overview of Command Organization
================================
The commands are organized roughly in the order which the user will use to come up with an
entity matching workflow.