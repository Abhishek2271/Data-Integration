========
Sampling
========
.. autofunction:: py_entitymatching.sample_table