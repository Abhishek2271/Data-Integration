==========================
Extracting Feature Vectors
==========================
.. autofunction:: py_entitymatching.extract_feature_vecs