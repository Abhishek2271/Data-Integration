===============================
Evaluating the Matching Output
===============================

.. autofunction:: py_entitymatching.eval_matches
.. autofunction:: py_entitymatching.print_eval_summary
.. autofunction:: py_entitymatching.get_false_positives_as_df
.. autofunction:: py_entitymatching.get_false_negatives_as_df
