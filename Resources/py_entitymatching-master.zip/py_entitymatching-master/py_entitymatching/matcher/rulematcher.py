"""
This module contains functions for Rule Matcher.
Note: This will not be included in the first version of py_entitymatching.
"""
from py_entitymatching.matcher.matcher import Matcher

class RuleMatcher(Matcher):
    pass
