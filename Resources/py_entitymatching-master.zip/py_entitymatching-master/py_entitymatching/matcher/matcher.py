"""
This module contains the definition for high level matcher class.
"""
class Matcher(object):
    pass

